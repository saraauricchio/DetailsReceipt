﻿using System;

namespace Details_Receipt
{
    public enum SaleTax
    {
        Generic = 10,
        Book = 0,
        Food = 0,
        Medical = 0
    }

    class Product
    {
        public string _article;       
        public int _quantity;
        public double _price;
        public readonly SaleTax _saleTax;
        public bool _imported;      
        public const double _importDuty = 5;        

        public Product(string article, int quantity, double price, string rate, bool imported)
        {
            this._article = article;           
            this._quantity = quantity;
            this._price = price;            
            this._saleTax = (SaleTax)Enum.Parse(typeof(SaleTax), rate);
            this._imported = imported;            

        }



    }
}
