﻿namespace Details_Receipt
{
    partial class ReceiptOfShoppingBaskets
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.dGVShoppingBasket = new System.Windows.Forms.DataGridView();
            this.btnLoadShoppingBasket = new System.Windows.Forms.Button();
            this.gbShoppingBasket = new System.Windows.Forms.GroupBox();
            this.btnPrintReceipt = new System.Windows.Forms.Button();
            this.gBDetailsReceipt = new System.Windows.Forms.GroupBox();
            this.tBDetailsReceipt = new System.Windows.Forms.TextBox();
            this.oFDShoppingBasket = new System.Windows.Forms.OpenFileDialog();
            this.btnSaveReceiptTxt = new System.Windows.Forms.Button();
            this.sFDReceiptTxt = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.dGVShoppingBasket)).BeginInit();
            this.gbShoppingBasket.SuspendLayout();
            this.gBDetailsReceipt.SuspendLayout();
            this.SuspendLayout();
            // 
            // dGVShoppingBasket
            // 
            this.dGVShoppingBasket.AllowUserToAddRows = false;
            this.dGVShoppingBasket.AllowUserToDeleteRows = false;
            this.dGVShoppingBasket.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVShoppingBasket.Location = new System.Drawing.Point(6, 19);
            this.dGVShoppingBasket.Name = "dGVShoppingBasket";
            this.dGVShoppingBasket.ReadOnly = true;
            this.dGVShoppingBasket.Size = new System.Drawing.Size(764, 251);
            this.dGVShoppingBasket.TabIndex = 0;
            // 
            // btnLoadShoppingBasket
            // 
            this.btnLoadShoppingBasket.Location = new System.Drawing.Point(6, 285);
            this.btnLoadShoppingBasket.Name = "btnLoadShoppingBasket";
            this.btnLoadShoppingBasket.Size = new System.Drawing.Size(174, 23);
            this.btnLoadShoppingBasket.TabIndex = 1;
            this.btnLoadShoppingBasket.Text = "Load Shopping Basket .csv";
            this.btnLoadShoppingBasket.UseVisualStyleBackColor = true;
            this.btnLoadShoppingBasket.Click += new System.EventHandler(this.btnLoadShoppingBasket_Click);
            // 
            // gbShoppingBasket
            // 
            this.gbShoppingBasket.Controls.Add(this.btnPrintReceipt);
            this.gbShoppingBasket.Controls.Add(this.dGVShoppingBasket);
            this.gbShoppingBasket.Controls.Add(this.btnLoadShoppingBasket);
            this.gbShoppingBasket.Location = new System.Drawing.Point(21, 12);
            this.gbShoppingBasket.Name = "gbShoppingBasket";
            this.gbShoppingBasket.Size = new System.Drawing.Size(776, 326);
            this.gbShoppingBasket.TabIndex = 2;
            this.gbShoppingBasket.TabStop = false;
            this.gbShoppingBasket.Text = "Shopping Basket";
            // 
            // btnPrintReceipt
            // 
            this.btnPrintReceipt.Location = new System.Drawing.Point(625, 285);
            this.btnPrintReceipt.Name = "btnPrintReceipt";
            this.btnPrintReceipt.Size = new System.Drawing.Size(144, 23);
            this.btnPrintReceipt.TabIndex = 2;
            this.btnPrintReceipt.Text = "Print Receipt";
            this.btnPrintReceipt.UseVisualStyleBackColor = true;
            this.btnPrintReceipt.Click += new System.EventHandler(this.btnPrintReceipt_Click);
            // 
            // gBDetailsReceipt
            // 
            this.gBDetailsReceipt.Controls.Add(this.btnSaveReceiptTxt);
            this.gBDetailsReceipt.Controls.Add(this.tBDetailsReceipt);
            this.gBDetailsReceipt.Location = new System.Drawing.Point(24, 372);
            this.gBDetailsReceipt.Name = "gBDetailsReceipt";
            this.gBDetailsReceipt.Size = new System.Drawing.Size(766, 269);
            this.gBDetailsReceipt.TabIndex = 3;
            this.gBDetailsReceipt.TabStop = false;
            this.gBDetailsReceipt.Text = "Details Receipt";
            // 
            // tBDetailsReceipt
            // 
            this.tBDetailsReceipt.Enabled = false;
            this.tBDetailsReceipt.Location = new System.Drawing.Point(24, 34);
            this.tBDetailsReceipt.Multiline = true;
            this.tBDetailsReceipt.Name = "tBDetailsReceipt";
            this.tBDetailsReceipt.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tBDetailsReceipt.Size = new System.Drawing.Size(719, 136);
            this.tBDetailsReceipt.TabIndex = 0;
            // 
            // oFDShoppingBasket
            // 
            this.oFDShoppingBasket.FileName = "oFDShoppingBasket";
            // 
            // btnSaveReceiptTxt
            // 
            this.btnSaveReceiptTxt.Location = new System.Drawing.Point(616, 240);
            this.btnSaveReceiptTxt.Name = "btnSaveReceiptTxt";
            this.btnSaveReceiptTxt.Size = new System.Drawing.Size(144, 23);
            this.btnSaveReceiptTxt.TabIndex = 1;
            this.btnSaveReceiptTxt.Text = "Save Receipt .txt";
            this.btnSaveReceiptTxt.UseVisualStyleBackColor = true;
            this.btnSaveReceiptTxt.Click += new System.EventHandler(this.btnSaveReceiptTxt_Click);
            // 
            // ReceiptOfShoppingBaskets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 653);
            this.Controls.Add(this.gBDetailsReceipt);
            this.Controls.Add(this.gbShoppingBasket);
            this.Name = "ReceiptOfShoppingBaskets";
            this.Text = "Receipt Of Shopping Baskets";
            ((System.ComponentModel.ISupportInitialize)(this.dGVShoppingBasket)).EndInit();
            this.gbShoppingBasket.ResumeLayout(false);
            this.gBDetailsReceipt.ResumeLayout(false);
            this.gBDetailsReceipt.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dGVShoppingBasket;
        private System.Windows.Forms.Button btnLoadShoppingBasket;
        private System.Windows.Forms.GroupBox gbShoppingBasket;
        private System.Windows.Forms.GroupBox gBDetailsReceipt;
        private System.Windows.Forms.TextBox tBDetailsReceipt;
        private System.Windows.Forms.Button btnPrintReceipt;
        private System.Windows.Forms.OpenFileDialog oFDShoppingBasket;
        private System.Windows.Forms.Button btnSaveReceiptTxt;
        private System.Windows.Forms.SaveFileDialog sFDReceiptTxt;
    }
}

