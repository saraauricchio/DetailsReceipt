﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace Details_Receipt
{
    public partial class ReceiptOfShoppingBaskets : Form
    {

        List<Product> Products = null;
        public ReceiptOfShoppingBaskets()
        {
            InitializeComponent();
        }

        private void btnLoadShoppingBasket_Click(object sender, EventArgs e)
        {
            try
            {

                tBDetailsReceipt.Text = "";

                var filePath = string.Empty;


                OpenFileDialog oFDShoppingBasket = new OpenFileDialog
                {
                    InitialDirectory = @"C:\",
                    Title = "Browse Shopping Basket csv files",

                    CheckFileExists = true,
                    CheckPathExists = true,

                    DefaultExt = "csv",
                    Filter = "csv files (*.csv)|*.csv",
                    FilterIndex = 2,
                    RestoreDirectory = false,

                    ReadOnlyChecked = true,
                    ShowReadOnly = true
                };

                if (oFDShoppingBasket.ShowDialog() == DialogResult.OK)
                {
                    filePath = oFDShoppingBasket.FileName;
                }   

                LoadCSVOnDataGridView(filePath);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void LoadCSVOnDataGridView(string fileName)
        {
            try
            {
                ReadCSV csv = new ReadCSV(fileName, true);

                try
                {
                    dGVShoppingBasket.DataSource = csv.readCSV;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void btnPrintReceipt_Click(object sender, EventArgs e)
        {
            try
            {
                tBDetailsReceipt.Text = "";

                if (dGVShoppingBasket.Rows.Count == 0)
                {
                    return;
                }

                Products = new List<Product>();

                foreach (DataGridViewRow row in dGVShoppingBasket.Rows)
                {
                    Products.Add(new Product(row.Cells["Article"].Value.ToString(), Convert.ToInt32(row.Cells["Quantity"].Value), Convert.ToDouble(row.Cells["Price"].Value), row.Cells["Type of good"].Value.ToString(), Convert.ToBoolean(row.Cells["Imported"].Value)));
                }

                PrintShoppingBasket();

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        private void PrintShoppingBasket()
        {
            try
            {
                double finalPrice = 0;
                double saleTax = 0;
                double importDuty = 0;
                double salesTaxes = 0;
                double total = 0;
                int found;
                int lastDecimal;

                foreach (Product product in Products)
                {
                    if (product._saleTax == SaleTax.Generic)
                    {                        

                      saleTax = Math.Round((product._price * (Convert.ToDouble(SaleTax.Generic)/100)),2);

                        found = saleTax.ToString().IndexOf(",");
                        if (found != -1 && saleTax.ToString().Substring(found).Length > 2)
                        {
                            lastDecimal = Convert.ToInt32(saleTax.ToString().Substring(found + 2));
                            if (lastDecimal > 5)
                            {
                                saleTax = Math.Round((product._price * (Convert.ToDouble(SaleTax.Generic) / 100)),1);                                
                            }
                        }
                        saleTax = saleTax * product._quantity;

                    }     

                    if (product._imported == true )
                    {
                        
                        importDuty = Math.Round((product._price * (Product._importDuty / 100)), 2);
                        found = importDuty.ToString().IndexOf(",");

                        if (found != -1 && importDuty.ToString().Substring(found).Length >2) 
                        {
                            lastDecimal = Convert.ToInt32(importDuty.ToString().Substring(found + 2));
                            if (lastDecimal > 5)
                            {
                                importDuty = Math.Round((product._price * (Product._importDuty / 100)), 1);
                            }

                        }
                        importDuty = importDuty * product._quantity;
              
                    }

                    finalPrice = Math.Round(product._price* product._quantity, 2) + saleTax + importDuty;

                    total = total + finalPrice;

                    salesTaxes = salesTaxes + saleTax + importDuty;

                    saleTax = 0;
                    importDuty = 0;

                    tBDetailsReceipt.Text = tBDetailsReceipt.Text + product._quantity + " " + product._article  + ": " + finalPrice.ToString("0.00") + "\r\n"; 

                }

                if (salesTaxes > 0)
                {

                    tBDetailsReceipt.Text  = tBDetailsReceipt.Text   + "Sales Tax:" + salesTaxes.ToString("0.00") + "\r\n"; 
                }

                tBDetailsReceipt.Text = tBDetailsReceipt.Text + "Total:" + total.ToString("0.00");



            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        private void btnSaveReceiptTxt_Click(object sender, EventArgs e)
        {
            try
            {
                if (tBDetailsReceipt.Text.Length == 0)
                {
                    return;
                }

                SaveFileDialog sFDReceiptTxt = new SaveFileDialog();
                sFDReceiptTxt.Filter = "txt File|*.txt";
                sFDReceiptTxt.Title = "Save Receipt txt";
                sFDReceiptTxt.ShowDialog();
               
                if (sFDReceiptTxt.FileName != "")

                    File.WriteAllText(sFDReceiptTxt.FileName, tBDetailsReceipt.Text);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
    }
}
