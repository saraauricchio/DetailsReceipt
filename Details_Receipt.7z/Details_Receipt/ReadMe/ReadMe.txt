Decompattare lo zip SalesTaxesProblem.
Aprire la cartella Details_Receipt.
Per eseguire l'applicativo aprire la solution Details_Receipt.sln con Visual Studio Coomunity.
Salvare la cartella INPUT CSV contenente i baskets di spesa.
Eseguire l'applicativo da Visual Studio da Debug - Avvia Debug
Caricare il csv con il basket di spesa nella griglia attraverso il bottone Load Shopping Basket .csv
Premere il bottone Print Receipt per visualizzare la ricevuta nella textbox di Details Receipt.
Salvare il file della ricevuta attraverso il bottone Save Receipt txt 